

from typing import Union
from unittest.main import MODULE_EXAMPLES
from fastapi import FastAPI, Request, Depends
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from pydantic import model_serializer
from config.db import get_db
from sqlalchemy.orm import Session
from schemas.note import NoteBase

app = FastAPI()

templates = Jinja2Templates(directory="templates")

@app.get("/")
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/search")
async def search(query: NoteBase, db: Session = Depends(get_db)):
    # Call the database function to search for the response
    response = db.query(MODULE_EXAMPLES.Note).filter(model_serializer.Note.content.like(f"%{query.content}%")).first()
    if response:
        return JSONResponse(content={"response": response.content})
    else:
        return JSONResponse(content={"response": "No results found."})

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8001)




