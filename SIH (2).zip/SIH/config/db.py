from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models.note import Base

# Database URL (replace with your actual MySQL database URL)
DATABASE_URL = "mysql+mysqlconnector://root:Sqlinobj?(no)@localhost/chatbot"

# Create the database engine for MySQL
engine = create_engine(DATABASE_URL, echo=True)

# Create a sessionmaker
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create the database tables
Base.metadata.create_all(bind=engine)

# Dependency to get a database session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
